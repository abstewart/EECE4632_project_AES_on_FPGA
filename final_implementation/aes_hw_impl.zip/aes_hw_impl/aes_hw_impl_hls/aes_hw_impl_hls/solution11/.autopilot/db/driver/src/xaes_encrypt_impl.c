// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2020.1 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xaes_encrypt_impl.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XAes_encrypt_impl_CfgInitialize(XAes_encrypt_impl *InstancePtr, XAes_encrypt_impl_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Axilites_BaseAddress = ConfigPtr->Axilites_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XAes_encrypt_impl_Set_key_const_V(XAes_encrypt_impl *InstancePtr, XAes_encrypt_impl_Key_const_v Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAes_encrypt_impl_WriteReg(InstancePtr->Axilites_BaseAddress, XAES_ENCRYPT_IMPL_AXILITES_ADDR_KEY_CONST_V_DATA + 0, Data.word_0);
    XAes_encrypt_impl_WriteReg(InstancePtr->Axilites_BaseAddress, XAES_ENCRYPT_IMPL_AXILITES_ADDR_KEY_CONST_V_DATA + 4, Data.word_1);
    XAes_encrypt_impl_WriteReg(InstancePtr->Axilites_BaseAddress, XAES_ENCRYPT_IMPL_AXILITES_ADDR_KEY_CONST_V_DATA + 8, Data.word_2);
    XAes_encrypt_impl_WriteReg(InstancePtr->Axilites_BaseAddress, XAES_ENCRYPT_IMPL_AXILITES_ADDR_KEY_CONST_V_DATA + 12, Data.word_3);
}

XAes_encrypt_impl_Key_const_v XAes_encrypt_impl_Get_key_const_V(XAes_encrypt_impl *InstancePtr) {
    XAes_encrypt_impl_Key_const_v Data;

    Data.word_0 = XAes_encrypt_impl_ReadReg(InstancePtr->Axilites_BaseAddress, XAES_ENCRYPT_IMPL_AXILITES_ADDR_KEY_CONST_V_DATA + 0);
    Data.word_1 = XAes_encrypt_impl_ReadReg(InstancePtr->Axilites_BaseAddress, XAES_ENCRYPT_IMPL_AXILITES_ADDR_KEY_CONST_V_DATA + 4);
    Data.word_2 = XAes_encrypt_impl_ReadReg(InstancePtr->Axilites_BaseAddress, XAES_ENCRYPT_IMPL_AXILITES_ADDR_KEY_CONST_V_DATA + 8);
    Data.word_3 = XAes_encrypt_impl_ReadReg(InstancePtr->Axilites_BaseAddress, XAES_ENCRYPT_IMPL_AXILITES_ADDR_KEY_CONST_V_DATA + 12);
    return Data;
}

