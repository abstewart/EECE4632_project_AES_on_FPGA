// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2020.1 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xaes_encrypt_impl.h"

extern XAes_encrypt_impl_Config XAes_encrypt_impl_ConfigTable[];

XAes_encrypt_impl_Config *XAes_encrypt_impl_LookupConfig(u16 DeviceId) {
	XAes_encrypt_impl_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XAES_ENCRYPT_IMPL_NUM_INSTANCES; Index++) {
		if (XAes_encrypt_impl_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XAes_encrypt_impl_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XAes_encrypt_impl_Initialize(XAes_encrypt_impl *InstancePtr, u16 DeviceId) {
	XAes_encrypt_impl_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XAes_encrypt_impl_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XAes_encrypt_impl_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

