// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2020.1 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// AXILiteS
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of key_const_V
//        bit 31~0 - key_const_V[31:0] (Read/Write)
// 0x14 : Data signal of key_const_V
//        bit 31~0 - key_const_V[63:32] (Read/Write)
// 0x18 : Data signal of key_const_V
//        bit 31~0 - key_const_V[95:64] (Read/Write)
// 0x1c : Data signal of key_const_V
//        bit 31~0 - key_const_V[127:96] (Read/Write)
// 0x20 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XAES_ENCRYPT_IMPL_AXILITES_ADDR_KEY_CONST_V_DATA 0x10
#define XAES_ENCRYPT_IMPL_AXILITES_BITS_KEY_CONST_V_DATA 128

